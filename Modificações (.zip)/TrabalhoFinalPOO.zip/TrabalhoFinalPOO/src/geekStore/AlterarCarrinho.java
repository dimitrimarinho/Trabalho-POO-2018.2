package geekStore;

public interface AlterarCarrinho {

		public void adicionarItem(Produto p);
		
}
