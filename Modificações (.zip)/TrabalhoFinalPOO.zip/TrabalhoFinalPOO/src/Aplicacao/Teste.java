package Aplicacao;

import menus.*;

public class Teste {
	
	public static void main(String[] args) {
		Menus.menuLogin();
	}
	 
}
