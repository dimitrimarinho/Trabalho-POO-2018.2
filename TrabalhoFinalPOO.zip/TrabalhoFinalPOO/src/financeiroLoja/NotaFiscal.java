package financeiroLoja;

public class NotaFiscal {

}
