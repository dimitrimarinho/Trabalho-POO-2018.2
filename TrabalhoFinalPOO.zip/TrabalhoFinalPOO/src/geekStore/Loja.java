package geekStore;

import java.util.ArrayList;

import financeiroLoja.*;

public class Loja {
	private static final String nome = "Geek Store";
	private static ArrayList<Produto> Estoque = new ArrayList<Produto>();
	private static ArrayList<Cliente> listaClientes = new ArrayList<Cliente>();
	private static ArrayList<FormaPagamento> listaFormasPagamento = new ArrayList<FormaPagamento>();
	
	
	public static void adicionarProduto(Produto p) {
		Estoque.add(p);
	}
	
	public static void adicionarCliente(Cliente c) {
		listaClientes.add(c);
	}
	
	public static void adicionarFormaPagamento(FormaPagamento f) {
		listaFormasPagamento.add(f);
	}
	
	public static void removerProduto(String id) {
		for(int i = 0; i < Estoque.size(); i++) {
			if(id.equals(Estoque.get(i).getId())){
				Estoque.remove(Estoque.get(i));
			}
		}
	}
	
	public static void removerCliente(String nome) {
		for(int i = 0; i < listaClientes.size(); i++) {
			if(nome.equals(listaClientes.get(i).getNome())){
				listaClientes.remove(listaClientes.get(i));
			}
		}
	}
	
	public static void removerFormaPagamento(int id) {
		for(int i = 0; i < listaFormasPagamento.size(); i++) {
			if(id == listaFormasPagamento.get(i).getId()){
				listaFormasPagamento.remove(listaFormasPagamento.get(i));
			}
		}
	}
	
	

	public static ArrayList<Produto> getEstoque() {
		return Estoque;
	}

	public static void setEstoque(ArrayList<Produto> estoque) {
		Estoque = estoque;
	}

	public static ArrayList<Cliente> getListaClientes() {
		return listaClientes;
	}

	public static void setListaClientes(ArrayList<Cliente> listaClientes) {
		Loja.listaClientes = listaClientes;
	}

	public static ArrayList<FormaPagamento> getListaFormasPagamento() {
		return listaFormasPagamento;
	}

	public static void setListaFormasPagamento(ArrayList<FormaPagamento> listaFormasPagamento) {
		Loja.listaFormasPagamento = listaFormasPagamento;
	}

	public static String getNome() {
		return nome;
	}
	
	
	
}
