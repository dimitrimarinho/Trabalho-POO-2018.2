package menus;

import cadastroClientes.*;
import cadastroFormasPagamento.*;
import cadastroProdutos.*;
import exibirClientes.*;
import exibirFormasPagamento.*;
import exibirProdutos.*;
import financeiroLoja.*;
import geekStore.*;
import icones.*;

import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;


public class Menus {
	
	
	public static void menuConsultarFormasPagamento() {
		ArrayList <FormaPagamento> listapag = Loja.getListaFormasPagamento();
		for(int i = 0; i < listapag.size(); i++) {
			if(listapag.get(i) instanceof CartaoCredito ) {
				ExibirFormasPagamento.exibirFormaPagamento((CartaoCredito) listapag.get(i));
			}else if(listapag.get(i) instanceof BoletoBancario) {
				ExibirFormasPagamento.exibirFormaPagamento((BoletoBancario) listapag.get(i));
			}
		}	
	}
	
	
	public static void menuConsultarClientes() {
		ArrayList <Cliente> lista = Loja.getListaClientes();
		for(int i = 0; i < lista.size(); i++) {
			if(lista.get(i) instanceof PessoaFisica ) {
				ExibirClientes.exibirPessoa((PessoaFisica) lista.get(i));
			}else if(lista.get(i) instanceof PessoaJuridica) {
				ExibirClientes.exibirPessoa((PessoaJuridica) lista.get(i));
			}
		}	
	}
	
	public static void menuConsultarCatalogo() {
		
		
	}
	
	
	public static void menuCadastroFormasPagamento() {
		FormaPagamento f;
		int cont = 0;
		ImageIcon logo = icones.Icones.iconeLoja();
		String verif = "S";
		
		while(verif.equalsIgnoreCase("S") || verif.equalsIgnoreCase("Sim")){
			String op =  (String) JOptionPane.showInputDialog(null,
			"Selecione a Forma de Pagamento que Deseja Cadastrar:\n"
			+"(1) - Cartao de Credito"
			+"\n(2) - Boleto Bancario"
			,"Geek Store", 0, logo, null, "");
			
			switch(op) {
			
			case "1":
				f = CadastroFormasPagamento.cadastroCartao();
				Loja.adicionarFormaPagamento(f);
				break;
			
			case "2":
				f = CadastroFormasPagamento.cadastroBoleto();
				Loja.adicionarFormaPagamento(f);
				break;
				
				 
			default:
				JOptionPane.showMessageDialog(null, "         Opcao Invalida!");
				cont = 1;
				
			}
			
			if(cont!=1) {
				JOptionPane.showMessageDialog(null, "Forma de Pagamento Cadastrada Com Sucesso!");
			}
			
			verif = JOptionPane.showInputDialog("Deseja Voltar Ao Menu de Cadastro?");
		}
		
	}
	
	
	public static void menuCadastroClientes() {
		Cliente c;
		int cont = 0;
		ImageIcon logo = icones.Icones.iconeLoja();
		String verif = "S";
		
		while(verif.equalsIgnoreCase("S") || verif.equalsIgnoreCase("Sim")){
			String op =  (String) JOptionPane.showInputDialog(null,
			"Selecione o Tipo de Cliente que Deseja Cadastrar:\n"
			+"(1) - Pessoa Fisica"
			+"\n(2) - Pessoa Juridica"
			,"Geek Store", 0, logo, null, "");
			
			switch(op) {
			
			case "1":
				c = CadastroClientes.cadastrarFisica();
				Loja.adicionarCliente(c);
				break;
			
			case "2":
				c = CadastroClientes.cadastroJuridica();
				Loja.adicionarCliente(c);
				break;
				
				 
			default:
				JOptionPane.showMessageDialog(null, "         Opcao Invalida!");
				cont = 1;
				
			}
			
			if(cont!=1) {
				JOptionPane.showMessageDialog(null, "Cliente Cadastrado Com Sucesso!");
			}
			
			verif = JOptionPane.showInputDialog("Deseja Voltar Ao Menu de Cadastro?");
		}
			
	}
		
	
	
	public static void menuCadastroProdutos() {
		Produto p;
		int cont = 0;
		ImageIcon logo = icones.Icones.iconeLoja();
		String verif = "S";
		
		while(verif.equalsIgnoreCase("S") || verif.equalsIgnoreCase("Sim")){
			String op =  (String) JOptionPane.showInputDialog(null,
			"Selecione o Produto que Deseja Cadastrar:\n"
			+"\n(1) - Camisa"
			+"\n(2) - Colecionavel"
			+"\n(3) - Livro"
			+"\n(4) - Jogo"
			+"\n(5) - Quadrinho"
			+"\n(6) - Manga"
			+"\n(7) - Botton"
			+"\n(8) - Estojo"
			,"Geek Store", 0, logo, null, "");
			
			switch(op) {
			
			case "1":
				p = CadastroProdutos.cadastroCamisa();
				Loja.adicionarProduto(p);
				break;
			
			case "2":
				p = CadastroProdutos.cadastroColecionaveis();
				Loja.adicionarProduto(p);
				break;
				
			case "3":
				p = CadastroProdutos.cadastroLivro();
				Loja.adicionarProduto(p);
				break;
				
			case "4":
				p = CadastroProdutos.cadastroGames();
				Loja.adicionarProduto(p);
				break;
				
			case "5":
				p = CadastroProdutos.cadastroQuadrinho();
				Loja.adicionarProduto(p);
				break;
				
			case "6":
				p = CadastroProdutos.cadastroManga();
				Loja.adicionarProduto(p);
				break;
				
			case "7":
				p = CadastroProdutos.cadastroBotton();
				Loja.adicionarProduto(p);
				break;
				
			case "8":
				 p = CadastroProdutos.cadastroEstojo();
				 Loja.adicionarProduto(p);
				 break;
				 
			default:
				JOptionPane.showMessageDialog(null, "         Opcao Invalida!");
				cont = 1;
				
			}
			
			if(cont!=1) {
				JOptionPane.showMessageDialog(null, "Produto Cadastrado Com Sucesso!");
			}
			
			verif = JOptionPane.showInputDialog("Deseja Voltar Ao Menu de Cadastro?");
		}
			
	}
		
	
	
	public static void menuApresentacao() {
		ImageIcon logo = icones.Icones.iconeLoja();
		String verif = "S";
		
		while(verif.equalsIgnoreCase("S") || verif.equalsIgnoreCase("Sim")){
			String op =  (String) JOptionPane.showInputDialog(null,
			"          BEM-VINDOS A GEEK STORE!"
			+"\n      A Loja Geek Mais Proxima de Voce!"
			+"\n\nSelecione a Opcao Desejada:\n"
			+"\n(1) - Para Cadastrar Produtos"
			+"\n(2) - Para Cadastrar Clientes"
			+"\n(3) - Para Cadastrar Formas de Pagamento"
			+"\n(4) - Para Consultar o Catalogo"
			+"\n(5) - Para Consultar Clientes Cadastrados"
			+"\n(6) - Para Consultar as Formas de Pagamento"
			,"Geek Store", 0, logo, null, "");
			
			switch(op) {
			
			case "1":
				menuCadastroProdutos();
				break;
			
			case "2":
				menuCadastroClientes();
				break;
				
			case "3":
				menuCadastroFormasPagamento();
				break;
				
			case "4":
				menuConsultarCatalogo();
				break;
				
			case "5":
				menuConsultarClientes();
				break;
				
			case "6":
				menuConsultarFormasPagamento();
				break;
				
			default:
				JOptionPane.showMessageDialog(null, "         Opcao Invalida!");
				
			}
			
			verif = JOptionPane.showInputDialog("Deseja Voltar Ao Menu Principal?");
		}
		
		JOptionPane.showMessageDialog(null, "VOLTE SEMPRE!", "Geek Store", 0, logo);
			
	}

}
